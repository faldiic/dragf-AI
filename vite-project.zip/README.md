# Capstone Project Vite

This project was bootstrapped with [Vite](https://vitejs.dev/) and uses React.

## Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Build for production
- `npm run preview` - Preview the production build

## Getting Started

1. Install dependencies: `npm install`
2. Start the dev server: `npm run dev`

For more information, see the [Vite documentation](https://vitejs.dev/).
